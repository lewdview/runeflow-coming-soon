# 🔥 FlowRune - Viral ASMR Creator

**Rune:** ᛚᚱ (Laguz-Raidho) - The FlowRune  
**Ancient Meaning:** Flow + Journey = Viral Content Creation  
**Modern Power:** AI-Powered ASMR Video Automation  
**Value:** $97 (FREE in RuneFlow Starter Pack)

---

## 🎯 What This Template Does

Creates viral glass-cutting ASMR videos automatically and posts them across multiple social platforms every 8 hours.

### ✨ Key Features

- 🤖 **AI-Powered Content Creation** - Generates unique glass object ideas
- 🎥 **Professional Video Generation** - Uses Fal AI + Google Veo 3
- 📱 **Multi-Platform Automation** - Auto-posts to YouTube, TikTok, Instagram
- 🔄 **Scheduled Execution** - Runs every 8 hours automatically
- 📊 **Content Tracking** - Google Sheets integration for analytics
- 🎨 **Glass-Cutting Aesthetic** - Hyper-realistic ASMR visuals
- 🔊 **4-Layer Sound Design** - Professional audio optimization

---

## 📁 Files Included

1. **`flowrune-asmr-workflow.json`** - Complete n8n workflow (main file)
2. **`SETUP_GUIDE.md`** - Detailed step-by-step setup instructions
3. **`tracking-sheet-template.csv`** - Google Sheets template for analytics
4. **`example-credentials.json`** - Sample credential configuration
5. **`test-data.json`** - Sample data for testing the workflow
6. **`README.md`** - This documentation

---

## ⚡ Quick Start (5 Minutes)

### 1. **Import Workflow**
```bash
1. Open your n8n instance
2. Click "Import from File"
3. Select "flowrune-asmr-workflow.json"
4. Click "Import"
```

### 2. **Required API Keys**
- **OpenRouter API** - For AI agents (get at openrouter.ai)
- **Fal AI API** - For video generation (get at fal.ai)
- **Blotato API** - For social media posting (get at blotato.com)
- **Google Sheets API** - For analytics tracking

### 3. **Configure Credentials**
1. In n8n, go to "Settings" → "Credentials"
2. Add each API key using the examples in `example-credentials.json`
3. Test each connection

### 4. **Set Up Google Sheets**
1. Create a new Google Sheet
2. Import the headers from `tracking-sheet-template.csv`
3. Copy the sheet ID and add to the workflow

### 5. **Test & Activate**
1. Click "Execute Workflow" to test
2. Check your Google Sheet for results
3. If successful, activate the Schedule Trigger

---

## 🎬 Expected Results

**Content Output:**
- High-quality 9:16 vertical ASMR videos
- Glass objects being cut with satisfying sounds
- Professional cinematic quality
- 15-30 second duration

**Posting Schedule:**
- Automatic posting every 8 hours
- YouTube Shorts, TikTok, Instagram Reels
- Unique content each time
- Analytics tracking in Google Sheets

**Engagement Potential:**
- High viral potential (glass-cutting ASMR is trending)
- Mobile-optimized aspect ratio
- Satisfying visual and audio experience
- Optimized for social media algorithms

---

## 🔧 Customization Options

### Change Posting Schedule
Edit the Schedule Trigger node to adjust frequency (currently 8 hours).

### Modify Glass Objects
Add your own object ideas to the Google Sheet to influence AI generation.

### Social Platform Selection
Enable/disable specific platforms in the Blotato posting nodes.

### Video Style Adjustments
Modify the prompt in the "Prompt Agent" node to change video aesthetics.

---

## 📊 Analytics & Monitoring

The workflow tracks:
- Generated objects and captions
- Video generation success/failure
- Social media posting status
- Engagement metrics (if connected)
- Error logs and debugging info

View your analytics in the connected Google Sheet.

---

## ❓ Troubleshooting

### Common Issues:

**Video Generation Fails:**
- Check Fal AI API credits and limits
- Verify prompt format in the Prompt Agent node

**Social Media Posting Fails:**
- Verify Blotato account limits and permissions
- Check platform-specific requirements

**Google Sheets Not Updating:**
- Verify Google Sheets API credentials
- Check sheet ID and permissions

### Getting Help:
- 📧 **Email:** support@runeflow.xyz
- 💬 **Discord:** discord.gg/runeflow  
- 🌐 **Documentation:** https://docs.runeflow.xyz

---

## 🚀 Upgrade Opportunities

This starter template can be enhanced with:
- **Advanced AI prompting** for more creative objects
- **Voice narration** using AI voice synthesis
- **Custom branding** overlays and watermarks
- **Advanced analytics** with click tracking
- **Multi-language support** for global reach

*Upgrade templates available in the full RuneFlow library.*

---

**May your content flow like water and journey like the wind.**

*— The RuneFlow Masters*

© 2025 RuneFlow.xyz - Ancient Power. Modern Automation.
