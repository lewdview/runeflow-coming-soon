# 🌊 Laguz - The Adapter

**Rune:** ᛚᚨᚷᚢᛉ (Laguz) - The Flow Rune  
**Ancient Meaning:** Water + Flow = Seamless Data Transformation  
**Modern Power:** Data Integration and Transformation Webhook  
**Value:** $29 (FREE in RuneFlow Starter Pack)

---

## 🎯 What This Template Does

A versatile webhook that receives data, transforms it using custom JavaScript, and returns the processed result. Perfect for integrating different systems and APIs.

### ✨ Key Features

- 🔄 **Data Transformation** - Convert data between different formats
- 🔗 **System Integration** - Bridge between different APIs and services
- ⚡ **Real-Time Processing** - Instant webhook responses
- 🛠️ **Custom Logic** - JavaScript code for complex transformations
- 📊 **Flexible Input/Output** - Handles JSON, XML, CSV, and more

---

## 📁 Files Included

1. **`laguz-adapter-workflow.json`** - Complete n8n workflow
2. **`transformation-examples.js`** - Sample JavaScript transformations
3. **`integration-patterns.json`** - Common integration scenarios
4. **`README.md`** - This documentation

---

## ⚡ Quick Start

### 1. **Import Workflow**
1. Open your n8n instance
2. Click "Import from File"
3. Select "laguz-adapter-workflow.json"
4. Click "Import"

### 2. **Activate Webhook**
1. Click on the "Data Sync Webhook" node
2. Copy the webhook URL
3. The workflow is now ready to receive data

### 3. **Test the Webhook**
```bash
curl -X POST https://your-n8n-instance.com/webhook/data-sync \
  -H "Content-Type: application/json" \
  -d '{"id": "123", "name": "Test User", "email": "test@example.com"}'
```

### 4. **Customize Transformation**
1. Click on the "Transform Data" node
2. Edit the JavaScript code to match your needs
3. Use the examples in `transformation-examples.js`

---

## 🔧 Common Use Cases

### 1. **CRM Data Syncing**
Transform lead data between different CRM systems:
- Salesforce → HubSpot
- Pipedrive → Monday.com
- Custom forms → Any CRM

### 2. **E-commerce Integration**
Sync product data between platforms:
- Shopify → WooCommerce
- Square → Stripe
- Inventory management systems

### 3. **API Format Conversion**
Convert between different API formats:
- REST → GraphQL
- XML → JSON
- CSV → Database records

### 4. **Data Enrichment**
Add additional data to incoming requests:
- Geo-location from IP
- Company data from email domain
- Social media profiles

---

## 💻 Customization Examples

### Basic Data Transformation
```javascript
// Transform user data
const transformedData = {
  id: $input.first().json.id,
  fullName: `${$input.first().json.firstName} ${$input.first().json.lastName}`,
  email: $input.first().json.email.toLowerCase(),
  timestamp: new Date().toISOString(),
  source: 'laguz-adapter'
};

return { json: transformedData };
```

### Data Enrichment
```javascript
// Enrich with additional data
const originalData = $input.first().json;
const enrichedData = {
  ...originalData,
  emailDomain: originalData.email.split('@')[1],
  leadScore: originalData.email.includes('gmail') ? 85 : 70,
  industry: originalData.company ? 'enterprise' : 'individual',
  processedAt: new Date().toISOString()
};

return { json: enrichedData };
```

### Format Conversion
```javascript
// Convert from one format to another
const input = $input.first().json;
const hubspotFormat = {
  properties: {
    email: input.email,
    firstname: input.name.split(' ')[0],
    lastname: input.name.split(' ')[1] || '',
    company: input.company || '',
    phone: input.phone || ''
  }
};

return { json: hubspotFormat };
```

---

## 🔌 Integration Patterns

### Pattern 1: **Form → CRM**
```javascript
// Transform form submission to CRM format
const formData = $input.first().json;
const crmData = {
  contact: {
    email: formData.email,
    firstName: formData.first_name,
    lastName: formData.last_name,
    company: formData.company,
    source: 'website_form',
    tags: ['lead', 'website'],
    customFields: {
      utm_source: formData.utm_source,
      page_url: formData.referrer
    }
  }
};
return { json: crmData };
```

### Pattern 2: **E-commerce → Analytics**
```javascript
// Transform order data for analytics
const order = $input.first().json;
const analyticsEvent = {
  event: 'purchase',
  user_id: order.customer_id,
  properties: {
    revenue: order.total_amount,
    currency: order.currency,
    items: order.line_items.map(item => ({
      name: item.product_name,
      category: item.category,
      quantity: item.quantity,
      price: item.price
    }))
  },
  timestamp: new Date().toISOString()
};
return { json: analyticsEvent };
```

---

## 📊 Advanced Features

### Error Handling
```javascript
try {
  const data = $input.first().json;
  
  // Validate required fields
  if (!data.email) {
    throw new Error('Email is required');
  }
  
  // Process data
  const result = processData(data);
  return { json: result };
  
} catch (error) {
  return { 
    json: { 
      error: error.message, 
      status: 'failed',
      timestamp: new Date().toISOString() 
    } 
  };
}
```

### Conditional Logic
```javascript
const data = $input.first().json;

// Different processing based on data type
if (data.type === 'user') {
  return { json: processUser(data) };
} else if (data.type === 'order') {
  return { json: processOrder(data) };
} else {
  return { json: processGeneric(data) };
}
```

---

## ❓ Troubleshooting

### Common Issues

**JavaScript Errors**
- Check syntax in the Transform Data node
- Use `console.log()` for debugging
- Test with simple transformations first

**Webhook Not Responding**
- Verify webhook URL is correct
- Check if workflow is activated
- Test with curl or Postman

**Data Not Transforming**
- Check input data structure
- Verify field names match your JavaScript code
- Use the n8n expression editor to test

### Getting Help
- 📧 **Email:** support@runeflow.xyz
- 💬 **Discord:** discord.gg/runeflow  
- 🌐 **Documentation:** https://docs.runeflow.xyz

---

## 🚀 Next Steps

This basic adapter can be enhanced with:
- **Database connections** for data persistence
- **Multiple webhook endpoints** for different data types
- **Authentication** for secure data transfers
- **Retry logic** for failed transformations
- **Logging and monitoring** for data flow tracking

*Advanced templates available in the full RuneFlow library.*

---

**Flow like water, adapt like Laguz!**

*— The RuneFlow Masters*

© 2025 RuneFlow.xyz - Ancient Power. Modern Automation.
