// ====================
// LAGUZ TRANSFORMATION EXAMPLES
// ====================

// 1. BASIC USER DATA TRANSFORMATION
function transformUserData() {
  const data = $input.first().json;
  
  return {
    json: {
      id: data.id,
      fullName: `${data.firstName} ${data.lastName}`,
      email: data.email.toLowerCase(),
      phone: data.phone || '',
      timestamp: new Date().toISOString(),
      source: 'laguz-adapter'
    }
  };
}

// 2. CRM FORMAT CONVERSION (Salesforce to HubSpot)
function salesforceToHubSpot() {
  const sfData = $input.first().json;
  
  return {
    json: {
      properties: {
        email: sfData.Email,
        firstname: sfData.FirstName,
        lastname: sfData.LastName,
        company: sfData.Company,
        phone: sfData.Phone,
        leadstatus: sfData.Status.toLowerCase(),
        hs_lead_status: mapSalesforceToHubSpotStatus(sfData.Status),
        createdate: new Date(sfData.CreatedDate).toISOString()
      }
    }
  };
}

// Helper function for status mapping
function mapSalesforceToHubSpotStatus(sfStatus) {
  const statusMap = {
    'New': 'new',
    'Contacted': 'in_progress', 
    'Qualified': 'qualified',
    'Closed Won': 'customer',
    'Closed Lost': 'unqualified'
  };
  return statusMap[sfStatus] || 'new';
}

// 3. E-COMMERCE ORDER TRANSFORMATION
function transformOrderData() {
  const order = $input.first().json;
  
  return {
    json: {
      orderId: order.id,
      customerEmail: order.customer.email,
      orderTotal: parseFloat(order.total_price),
      currency: order.currency,
      orderDate: new Date(order.created_at).toISOString(),
      items: order.line_items.map(item => ({
        productId: item.product_id,
        productName: item.title,
        quantity: item.quantity,
        price: parseFloat(item.price),
        vendor: item.vendor || 'unknown'
      })),
      shippingAddress: {
        country: order.shipping_address?.country_code,
        state: order.shipping_address?.province,
        city: order.shipping_address?.city,
        zip: order.shipping_address?.zip
      },
      orderStatus: order.financial_status,
      fulfillmentStatus: order.fulfillment_status
    }
  };
}

// 4. DATA ENRICHMENT EXAMPLE
function enrichUserData() {
  const userData = $input.first().json;
  
  // Extract domain from email
  const emailDomain = userData.email.split('@')[1];
  
  // Calculate lead score based on email domain
  const leadScore = calculateLeadScore(emailDomain, userData);
  
  // Determine business vs personal
  const accountType = isBusinessEmail(emailDomain) ? 'business' : 'personal';
  
  return {
    json: {
      ...userData,
      emailDomain: emailDomain,
      leadScore: leadScore,
      accountType: accountType,
      industry: inferIndustry(emailDomain),
      companySize: inferCompanySize(userData.company),
      enrichedAt: new Date().toISOString(),
      followUpPriority: leadScore > 80 ? 'high' : leadScore > 60 ? 'medium' : 'low'
    }
  };
}

// Helper functions for data enrichment
function calculateLeadScore(emailDomain, userData) {
  let score = 50; // Base score
  
  // Domain scoring
  if (emailDomain.includes('gmail.com')) score += 20;
  if (emailDomain.includes('yahoo.com')) score += 15;
  if (!['gmail.com', 'yahoo.com', 'hotmail.com'].includes(emailDomain)) score += 25;
  
  // Company field scoring
  if (userData.company && userData.company.length > 2) score += 15;
  
  // Phone number scoring
  if (userData.phone && userData.phone.length > 5) score += 10;
  
  return Math.min(score, 100);
}

function isBusinessEmail(domain) {
  const personalDomains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'icloud.com'];
  return !personalDomains.includes(domain);
}

function inferIndustry(domain) {
  const industryMap = {
    '.edu': 'education',
    '.org': 'nonprofit',
    '.gov': 'government',
    'bank': 'financial',
    'tech': 'technology',
    'health': 'healthcare'
  };
  
  for (const [key, industry] of Object.entries(industryMap)) {
    if (domain.includes(key)) return industry;
  }
  
  return 'unknown';
}

function inferCompanySize(companyName) {
  if (!companyName) return 'unknown';
  
  const size = companyName.length;
  if (size < 10) return 'small';
  if (size < 20) return 'medium';
  return 'large';
}

// 5. XML TO JSON CONVERSION
function xmlToJsonTransform() {
  const xmlData = $input.first().json.xml;
  
  // Convert XML to JSON (simplified example)
  // In real implementation, you'd use a proper XML parser
  
  return {
    json: {
      convertedFrom: 'xml',
      data: parseXMLToJSON(xmlData),
      convertedAt: new Date().toISOString()
    }
  };
}

// 6. WEBHOOK RESPONSE FORMATTING
function formatWebhookResponse() {
  const processedData = $input.first().json;
  
  return {
    json: {
      success: true,
      message: 'Data processed successfully',
      data: processedData,
      timestamp: new Date().toISOString(),
      processingTime: calculateProcessingTime(),
      nextSteps: [
        'Data has been transformed',
        'Check your destination system',
        'Verify the integration worked correctly'
      ]
    }
  };
}

// 7. ERROR HANDLING EXAMPLE
function transformWithErrorHandling() {
  try {
    const data = $input.first().json;
    
    // Validate required fields
    if (!data.email) throw new Error('Email field is required');
    if (!data.name) throw new Error('Name field is required');
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      throw new Error('Invalid email format');
    }
    
    // Process the data
    const transformedData = {
      id: data.id || generateId(),
      name: data.name.trim(),
      email: data.email.toLowerCase().trim(),
      processedAt: new Date().toISOString()
    };
    
    return { json: transformedData };
    
  } catch (error) {
    return {
      json: {
        success: false,
        error: error.message,
        timestamp: new Date().toISOString(),
        originalData: $input.first().json
      }
    };
  }
}

// 8. CONDITIONAL PROCESSING
function conditionalTransform() {
  const data = $input.first().json;
  const dataType = data.type || 'unknown';
  
  switch (dataType) {
    case 'user':
      return transformUserData();
    case 'order':
      return transformOrderData();
    case 'lead':
      return enrichUserData();
    default:
      return {
        json: {
          error: `Unknown data type: ${dataType}`,
          supportedTypes: ['user', 'order', 'lead'],
          originalData: data
        }
      };
  }
}

// UTILITY FUNCTIONS
function generateId() {
  return Date.now().toString() + Math.random().toString(36).substr(2, 5);
}

function calculateProcessingTime() {
  // This would be implemented with actual timing logic
  return '0.05s';
}

// ====================
// USAGE EXAMPLES
// ====================

/*
To use these examples in your Laguz workflow:

1. Copy the function you want to use
2. Paste it into the "Transform Data" node
3. Make sure to call the function and return its result
4. Test with sample data

Example implementation in the Code node:

// Copy the function definition here
function transformUserData() {
  // ... function code ...
}

// Call the function and return result
return transformUserData();
*/
